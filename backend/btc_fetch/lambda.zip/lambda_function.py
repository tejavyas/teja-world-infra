import os
import json
import urllib.request
import boto3

# Retrieve WebSocket Management URL from environment variable
WEBSOCKET_URL = os.environ["WEBSOCKET_MANAGEMENT_URL"]
apigw_client = boto3.client("apigatewaymanagementapi", endpoint_url=WEBSOCKET_URL)

def send_websocket_update(message):
    """Send a message to connected WebSocket clients."""
    try:
        apigw_client.post_to_connection(
            ConnectionId="YOUR-CONNECTION-ID",  # You need to retrieve this dynamically
            Data=json.dumps(message)
        )
        print("WebSocket update sent:", message)
    except Exception as e:
        print("WebSocket Error:", str(e))

def lambda_handler(event, context):
    try:
        url = "https://api.coindesk.com/v1/bpi/currentprice/BTC.json"
        response = urllib.request.urlopen(url)
        data = json.loads(response.read())
        btc_price = data["bpi"]["USD"]["rate"]

        send_websocket_update({"btc_price": btc_price})
        
        return {"statusCode": 200, "body": json.dumps({"btc_price": btc_price})}
    except Exception as e:
        print("Error fetching BTC price:", str(e))
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
